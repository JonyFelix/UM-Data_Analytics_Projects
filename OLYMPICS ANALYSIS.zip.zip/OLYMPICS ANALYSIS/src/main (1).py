
import os
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from prophet import Prophet

def main():
    print("Welcome to My Project!\nOLYMPIC ANALYSIS")

    # ✅ Load the dataset
    df = pd.read_csv("Summer-Olympic-medals-1976-to-2008.csv", encoding="latin1")

    # ✅ Data Cleaning
    df = df.drop(columns=["Country_Code", "Event_gender"], errors="ignore")
    df["Year"] = df["Year"].astype("Int64")
    df = df.dropna().drop_duplicates()

    # ✅ Display dataset info
    print("\n✅ Cleaned Dataset Information:")
    print(df.info())

    # ✅ Basic Statistics
    print("\n🔹 Dataset Overview:")
    print(df.describe(include="all"))

    # ✅ Unique Value Counts
    print("\n🔹 Unique Cities:", df["City"].nunique())
    print("🔹 Unique Sports:", df["Sport"].nunique())
    print("🔹 Unique Disciplines:", df["Discipline"].nunique())
    print("🔹 Unique Events:", df["Event"].nunique())
    print("🔹 Unique Athletes:", df["Athlete"].nunique())
    print("🔹 Unique Countries:", df["Country"].nunique())

    # ✅ Medal & Gender Distribution
    medal_counts = df["Medal"].value_counts()
    gender_counts = df["Gender"].value_counts()

    print("\n🔹 Medal Distribution:\n", medal_counts)
    print("\n🔹 Gender Distribution:\n", gender_counts)

    # ✅ Visualization: Medal Distribution
    plt.figure(figsize=(6,4))
    sns.barplot(x=medal_counts.index, y=medal_counts.values, palette="coolwarm")
    plt.title("Medal Distribution")
    plt.xlabel("Medal Type")
    plt.ylabel("Count")
    plt.show()

    # ✅ Visualization: Gender Distribution
    plt.figure(figsize=(6,4))
    sns.barplot(x=gender_counts.index, y=gender_counts.values, palette="pastel")
    plt.title("Gender Distribution of Athletes")
    plt.xlabel("Gender")
    plt.ylabel("Count")
    plt.show()

    # ✅ Time-Series Forecasting with Prophet
    medal_trends = df.groupby("Year")["Medal"].count().reset_index()
    medal_trends.columns = ["ds", "y"]

    model = Prophet()
    model.fit(medal_trends)

    future = model.make_future_dataframe(periods=4, freq="4YE")
    forecast = model.predict(future)

    fig = model.plot(forecast)
    plt.title("Forecasted Olympic Medal Trends")
    plt.xlabel("Year")
    plt.ylabel("Total Medals")
    plt.show()

    # ✅ Save Forecast to Excel
    forecast.to_excel("Olympics_Medal_Forecast.xlsx", index=False)
    print("✅ Forecast saved as 'Olympics_Medal_Forecast.xlsx'")

if __name__ == "__main__":
    main()
